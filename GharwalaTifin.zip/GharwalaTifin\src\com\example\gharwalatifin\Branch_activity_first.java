package com.example.gharwalatifin;

import java.util.ArrayList;



import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Branch_activity_first extends ActionBarActivity {

	// Wigets - GUI
	Spinner spCity;
	Spinner spPlace;
	Button doneButton;
	// Data Source
	String chennai[] = { "AKSHAYA ADENA-Padur", 
			"AURO MILLS- Thoraipakkam", 
			"BOLLINENI HILLSIDE-Semencherry", 
			"DLF GARDEN CITY-Semencherry",
			"DREAM VILLA-Thoraipakkam", 
	"GLOBAL CITY - Perumbakkam" };

	String pune[]={"Kalyani Nagar",
			"Viman nagar",
			"Kasba Peth",
			"Chinchwad",
	"Dattawadi"};

	String kolkata[]={"Rajarhut",
			"Garia",
			"Alam Bazar",
			"Andul Road",
	"Bantick Street"};

	ArrayList<String[]> cities;

	String[] citiesStrings = new String[]{};
	String mobile;
	// Adapter
	ArrayAdapter<String> adapterLocationType;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_branch_activity_first);
		Intent intent = getIntent();
		mobile = intent.getStringExtra("mobile");
		//Toast.makeText(this, mobile, Toast.LENGTH_SHORT).show();
		cities = new ArrayList<String[]>();
		cities.add(chennai);
		cities.add(kolkata);
		cities.add(pune);
		// Initialize Spinners

		spCity = (Spinner) findViewById(R.id.spCity);
		spPlace = (Spinner) findViewById(R.id.spPlace);
		doneButton=(Button)findViewById(R.id.done_btn);
		//spPlace.setEnabled(false);
		// Initialize and set Adapter


		//spPlace.setAdapter(adapterBusinessType);

		// Country Item Selected Listener
		spCity.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> adapter, View v,
					int position, long id) {

				// On selecting a spinner item
				String item = adapter.getItemAtPosition(position).toString();
                
				// Showing selected spinner item
				//Toast.makeText(getApplicationContext(),
				//		"Selected Country : " + item, Toast.LENGTH_LONG).show();
				citiesStrings = cities.get(position);
				adapterLocationType = 
						new ArrayAdapter<String>(Branch_activity_first.this,
								android.R.layout.simple_spinner_item,cities.get(spCity.getSelectedItemPosition()));
				spPlace.setAdapter(adapterLocationType);
				//adapterBusinessType.notifyDataSetInvalidated();
				//adapterBusinessType.addAll(cities.get(position));
				adapterLocationType.notifyDataSetChanged();



			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});


		doneButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String sp1=spCity.getSelectedItem().toString();
				String sp2=spPlace.getSelectedItem().toString();		      
				Intent intent=new Intent(Branch_activity_first.this,ItemOrder.class);
				intent.putExtra("city", sp1);
				intent.putExtra("place", sp2);
				intent.putExtra("mobile", mobile);
				startActivity(intent);
			}
		});

		spPlace.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> adapter, View v,
					int position, long id) {
				// On selecting a spinner item
				String item = adapter.getItemAtPosition(position).toString();

				// Showing selected spinner item
				//Toast.makeText(getApplicationContext(),
					//	"Selected Location : " + item, Toast.LENGTH_LONG).show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});
	}
}
