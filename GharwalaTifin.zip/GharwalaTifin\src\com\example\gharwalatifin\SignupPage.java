package com.example.gharwalatifin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gharwalatifin.util.JSONParser;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.matesnetwork.Cognalys.VerifyMobile;
import com.matesnetwork.cogdemov2.CheckNetworkConnection;


import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class SignupPage extends Activity {

	Button test;
	EditText mobilenum;
	EditText countrycode;
    EditText etname,etpassword;
    ImageView imageicon;
    private ProgressDialog pDialog;
    private static String url = "http://myappchintu.16mb.com/gharwalatifin/signup.php";
    
    //gcm 
    public static final String EXTRA_MESSAGE = "message";
    public static final String PROPERTY_REG_ID = "registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
 // please enter your sender id
    String SENDER_ID = "269017631567";
    
    static final String TAG = "GCMDemo";
    GoogleCloudMessaging gcm;

    Context context1;
   static String regid;
    ProgressDialog  pDialog1;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_signup_page);
		context1=getApplicationContext();
		test = (Button) findViewById(R.id.test);
		mobilenum = (EditText) findViewById(R.id.editText1);
		countrycode = (EditText) findViewById(R.id.editText2);
		etname=(EditText)findViewById(R.id.editTextName);
		etpassword=(EditText)findViewById(R.id.editTextPassword);
		imageicon=(ImageView)findViewById(R.id.imageView1);
		new RegisterBackground().execute();
		countrycode.setText(VerifyMobile
				.getCountryCode(getApplicationContext()));
		test.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				if(test.getText().toString().equals("Verify"))
				{
				// TODO Auto-generated method stub
				String mobile = countrycode.getText().toString()
						+ mobilenum.getText().toString();
				Intent in = new Intent(SignupPage.this, VerifyMobile.class);

				in.putExtra("app_id", "e7e9960a47ae4130a799f94");
				in.putExtra("access_token",
						"d3e76fea6ace9e463de06865581845a79df7f038");
				in.putExtra("mobile", mobile);
				if (mobile.length() == 0) {
					countrycode.setError("Please enter mobile number");
				} else {
					if (CheckNetworkConnection
							.isConnectionAvailable(getApplicationContext())) {
						startActivityForResult(in, VerifyMobile.REQUEST_CODE);
					} else {
						Toast.makeText(getApplicationContext(),
								"no internet connection", Toast.LENGTH_SHORT)
								.show();
					}
				}

			}
				if(test.getText().toString().equals("Signup"))
				{
					
					new signup().execute();
				}
			}
			
			});
	}

	@Override
	protected void onActivityResult(int arg0, int arg1, Intent arg2) {
		// TODO Auto-generated method stub
		super.onActivityResult(arg0, arg1, arg2);
		int result = arg2.getIntExtra("result", 0);
		if(result==104)
		{
			mobilenum.setEnabled(false);
			etname.setVisibility(View.VISIBLE);
			etpassword.setVisibility(View.VISIBLE);
			imageicon.setVisibility(View.VISIBLE);
			test.setText("Signup");
			
		}
		else
		{
			imageicon.setImageResource(R.drawable.wrong);
			imageicon.setVisibility(View.VISIBLE);
		}

		/*if (arg0 == VerifyMobile.REQUEST_CODE) {
			String message = arg2.getStringExtra("message");
			int result = arg2.getIntExtra("result", 0);

			Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT)
					.show();
			Toast.makeText(getApplicationContext(), "" + result,
					Toast.LENGTH_SHORT).show();

		}*/
	}
	
	
	/**
	 * Background Async Task to Create new product
	 * */
	class signup extends AsyncTask<String, String, String> {
		
		private static final String TAG = "checkNumber";

		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(SignupPage.this);
			pDialog.setMessage("Signup process..");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();
		}

		/**
		 * Creating product
		 * @return 
		 * */
		protected String doInBackground(String... args) {

			String mobileNumber = mobilenum.getText().toString();
			String username = etname.getText().toString();
			String userpassword = etpassword.getText().toString();
           
			// Building Parameters
			List<NameValuePair> params = new ArrayList<NameValuePair>();

			params.add(new BasicNameValuePair("mobile", mobileNumber));
			params.add(new BasicNameValuePair("name", username));
			params.add(new BasicNameValuePair("password", userpassword));
			params.add(new BasicNameValuePair("devid", regid));

			try {
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost(url);
                httpPost.setEntity(new UrlEncodedFormEntity(params));

                HttpResponse response = httpClient.execute(httpPost);

                HttpEntity entity = response.getEntity();

              

            } catch (ClientProtocolException e) {

            } catch (IOException e) {

            }
			return null;

			
		}

		/**
		 * After completing background task Dismiss the progress dialog
		 * **/
		protected void onPostExecute(String result) {
			// dismiss the dialog once done
			pDialog.dismiss();
			Intent in=new Intent(SignupPage.this,Branch_activity_first.class);
			startActivity(in);
			// closing this screen
			finish();
			
		}

	}
	
	
	class RegisterBackground extends AsyncTask<String,String,String>{

		@Override
		 protected void onPreExecute() { 
            super.onPreExecute(); 
            pDialog1 = new ProgressDialog(SignupPage.this);
            pDialog1.setMessage("Getting Device ID..."); 
            pDialog1.setIndeterminate(false); 
            pDialog1.setCancelable(true); 
            pDialog1.show(); 
 
        } 
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			String msg = "";
			try {
                if (gcm == null) {
                    gcm = GoogleCloudMessaging.getInstance(context1);
                }
                regid = gcm.register(SENDER_ID);
                msg = "Dvice registered, registration ID=" + regid;
                Log.d("111", msg);
              //  sendRegistrationIdToBackend();
             //   Toast.makeText(context1, regid, Toast.LENGTH_LONG).show();    
	    	    // Persist the regID - no need to register again.
               storeRegistrationId(context1, regid);
            } catch (IOException ex) {
                msg = "Error :" + ex.getMessage();
            }
            return msg;
        }
		
		@Override
        protected void onPostExecute(String msg) {

     //       mDisplay.append(msg + "\n");
			 pDialog1.dismiss(); 
			 Toast.makeText(getApplicationContext(), regid, Toast.LENGTH_LONG).show(); 
       }
		
		private void storeRegistrationId(Context context, String regId) {
		    final SharedPreferences prefs = getGCMPreferences(context);
		    int appVersion = getAppVersion(context);
		    Log.i(TAG, "Saving regId on app version " + appVersion);
		    SharedPreferences.Editor editor = prefs.edit();
		    editor.putString(PROPERTY_REG_ID, regId);
		    editor.putInt(PROPERTY_APP_VERSION, appVersion);
		    editor.commit();
		}
		}
		
	private boolean checkPlayServices() {
	    int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
	    if (resultCode != ConnectionResult.SUCCESS) {
	        if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
	            GooglePlayServicesUtil.getErrorDialog(resultCode, this,
	                    PLAY_SERVICES_RESOLUTION_REQUEST).show();
	        } else {
	            Log.i(TAG, "This device is not supported.");
	            finish();
	        }
	        return false;
	    }
	    return true;
	}
	private String getRegistrationId(Context context) {
	    final SharedPreferences prefs = getGCMPreferences(context);
	    String registrationId = prefs.getString(PROPERTY_REG_ID, "");
	    if (registrationId.isEmpty()) {
	        Log.i(TAG, "Registration not found.");
	        return "";
	    }
	    
	    int registeredVersion = prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
	    int currentVersion = getAppVersion(context);
	    if (registeredVersion != currentVersion) {
	        Log.i(TAG, "App version changed.");
	        return "";
	    }
	    return registrationId;
	}
	
	private SharedPreferences getGCMPreferences(Context context) {
	    
	    return getSharedPreferences(MainActivity.class.getSimpleName(),
	            Context.MODE_PRIVATE);
	}
	
	private static int getAppVersion(Context context) {
	    try {
	        PackageInfo packageInfo = context.getPackageManager()
	                .getPackageInfo(context.getPackageName(), 0);
	        return packageInfo.versionCode;
	    } catch (NameNotFoundException e) {
	        // should never happen
	        throw new RuntimeException("Could not get package name: " + e);
	    }
	}
}
