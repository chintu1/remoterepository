package com.example.gharwalatifin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.fragmentpart.fragment.ItemList;
import com.example.fragmentpart.fragment.Itemdetail;
import com.example.fragmentpart.fragment.ItemList.OnitemSelectedListener;
import com.example.gharwalatifin.util.JSONParser;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class ItemOrder extends Activity implements OnitemSelectedListener {


	String city,place,mobile,address;
	Button checkout;
	String itemcode="";
	// Progress Dialog
	private ProgressDialog pDialog;
	String itemcount="";
	// url to create new product
	private static String url = "http://myappchintu.16mb.com/gharwalatifin/order.php";
	
	private static String url_gcm = "http://myappchintu.16mb.com/gcm.php";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_itemorder);
		Intent intent = getIntent();
		mobile = intent.getStringExtra("mobile");
		city=intent.getStringExtra("city");
		place=intent.getStringExtra("place");
		address=(place+","+city);

		//	Toast.makeText(this,"mobile="+ mobile, Toast.LENGTH_SHORT).show();
		//	Toast.makeText(this, "adress="+place+","+city, Toast.LENGTH_SHORT).show();

	}
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		//take handle of button n set its clicklistener in xml
		checkout=(Button)findViewById(R.id.buttoncheckout);
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	@Override
	public void onitemSelected(String title, int position) {
		// TODO Auto-generated method stub
		Itemdetail nFragment =
				(Itemdetail)
				getFragmentManager().findFragmentById(R.id.fragmentitemdetail);
		nFragment.updatenewUi(title,position);
	}

	public void checkout(View v) {
		//	Iterator<Integer> it=Itemdetail.ordereditem.keySet().iterator();

		//Store entry (Key/Value)of HashMap in set
		Set mapSet = (Set) Itemdetail.ordereditem.entrySet();
		//Create iterator on Set 
		Iterator mapIterator = mapSet.iterator();
		//  System.out.println("Display the key/value of HashMap.");
		while (mapIterator.hasNext()) {
			Map.Entry mapEntry = (Map.Entry) mapIterator.next();
			// getKey Method of HashMap access a key of map
			if(!(itemcode.equals("")))
			{
				itemcode=itemcode+"-";
			}
			if(!(itemcount.equals("")))
			{
				itemcount=itemcount+"-";
			}
			itemcode = itemcode+(mapEntry.getKey()).toString();
			//getValue method returns corresponding key's value
			itemcount =itemcount+(mapEntry.getValue()).toString();
			//    System.out.println("Key : " + keyValue + "= Value : " + value);
		}
		//Toast.makeText(this, ""+itemcode, Toast.LENGTH_SHORT).show();
		//Toast.makeText(this, ""+itemcount, Toast.LENGTH_SHORT).show();
		new itemorder().execute();
	}

	/**
	 * Background Async Task to Create new product
	 * */
	class itemorder extends AsyncTask<String, String, Boolean> {
		private static final String TAG_SUCCESS = "registered";
		JSONParser jsonParser = new JSONParser();

		private static final String TAG = "checkNumber";

		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(ItemOrder.this);
			pDialog.setMessage("Getting order..");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();
		}

		/**
		 * Creating product
		 * */
		protected Boolean doInBackground(String... args) {

			String itemid = itemcode;
			String Noofitem = itemcount;

			// Building Parameters
			List<NameValuePair> params = new ArrayList<NameValuePair>();

			params.add(new BasicNameValuePair("itemid", itemid));
			params.add(new BasicNameValuePair("noofitem", Noofitem));
			params.add(new BasicNameValuePair("address", address));
			params.add(new BasicNameValuePair("mobile", mobile));

			try {
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost(url);
				httpPost.setEntity(new UrlEncodedFormEntity(params));

				HttpResponse response = httpClient.execute(httpPost);

				HttpEntity entity = response.getEntity();



			} catch (ClientProtocolException e) {

			} catch (IOException e) {

			}
			return null;
		}

		/**
		 * After completing background task Dismiss the progress dialog
		 * **/
		protected void onPostExecute(Boolean result) {
			// dismiss the dialog once done
			pDialog.dismiss();


			new notification().execute();
		}

	}

	/**
	 * Background Async Task to Create new product
	 * */
	class notification extends AsyncTask<String, String, Boolean> {
		private static final String TAG_SUCCESS = "registered";
		JSONParser jsonParser = new JSONParser();

		private static final String TAG = "checkNumber";

		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(ItemOrder.this);
			pDialog.setMessage("Please wait..");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();
		}

		/**
		 * Creating product
		 * */
		protected Boolean doInBackground(String... args) {



			// Building Parameters
			List<NameValuePair> params = new ArrayList<NameValuePair>();

			params.add(new BasicNameValuePair("mobile", mobile));

			try {
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost(url_gcm);
				httpPost.setEntity(new UrlEncodedFormEntity(params));

				HttpResponse response = httpClient.execute(httpPost);

				HttpEntity entity = response.getEntity();



			} catch (ClientProtocolException e) {

			} catch (IOException e) {

			}
			return null;
		}

		/**
		 * After completing background task Dismiss the progress dialog
		 * **/
		protected void onPostExecute(Boolean result) {
			// dismiss the dialog once done
			pDialog.dismiss();

			Intent intent=new Intent(ItemOrder.this,Thankyou.class);
            startActivity(intent);
			finish();


		}

	}
}
