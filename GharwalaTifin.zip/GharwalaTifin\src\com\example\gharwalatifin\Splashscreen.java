package com.example.gharwalatifin;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.ImageView;

public class Splashscreen extends Activity {

	ImageView loading,logo,delveryboy;
	Animation animFadein,animFadein1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splashscreen);
        loading=(ImageView)findViewById(R.id.imageView2);
        logo=(ImageView)findViewById(R.id.imageView1);
        delveryboy=(ImageView)findViewById(R.id.imageView3);
        animFadein = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.rotate);
        animFadein1 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.slide_down);
        loading.startAnimation(animFadein);
        logo.startAnimation(animFadein1);
        TranslateAnimation animation = new TranslateAnimation(0.0f, 400.0f,
        	    0.0f, 0.0f);
        	  animation.setDuration(5000);
        	  animation.setRepeatCount(5);
        	  animation.setRepeatMode(2);
        	  animation.setFillAfter(true);
        	  delveryboy.startAnimation(animation);
;
		// METHOD 1     

		/****** Create Thread that will sleep for 5 seconds *************/        
		Thread background = new Thread() {
			public void run() {

				try {
					// Thread will sleep for 5 seconds
					sleep(5*1000);

					// After 5 seconds redirect to another intent
					Intent i=new Intent(getBaseContext(),MainActivity.class);
					startActivity(i);

					//Remove activity
					finish();

				} catch (Exception e) {

				}
			}
		};

		// start thread
		background.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splashscreen, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	 @Override
	    protected void onDestroy() {
	         
	        super.onDestroy();
	         
	    }
}
