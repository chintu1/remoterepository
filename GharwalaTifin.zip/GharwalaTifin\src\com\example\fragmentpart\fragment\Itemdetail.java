package com.example.fragmentpart.fragment;




import java.util.HashMap;

import android.R.integer;
import android.app.Fragment;
import android.os.Bundle;
import com.example.gharwalatifin.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Itemdetail extends Fragment implements OnClickListener {

	TextView detail,textitemtotal,textitemtotalprice;
	int positionofitem;
	Button addcart;
	EditText quantity;
	 int NoofItem=0;
	 int itemprice=0;
	public static HashMap<Integer, Integer> ordereditem;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view=inflater.inflate(R.layout.activity_itemdetail, null);
		super.onCreateView(inflater, container, savedInstanceState);
		detail=(TextView)view.findViewById(R.id.textViewdetail);
		addcart=(Button)view.findViewById(R.id.buttonAddcart);
		quantity=(EditText)view.findViewById(R.id.editTextquantity);
		textitemtotal=(TextView)view.findViewById(R.id.textViewtotalitem1);
		textitemtotalprice=(TextView)view.findViewById(R.id.textViewTotalprice1);
		ordereditem=new HashMap<Integer, Integer>();
		addcart.setOnClickListener(this);
		return view;
	}

	public void updatenewUi(String title, int position) {
		positionofitem=position;
		// TODO Auto-generated method stub
		detail.setText(title);

	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
     

		if(quantity.getText().toString().equals(""))
		{
			quantity.setError("Please Enter Quantity");
		}

		else
		{
			int quant=Integer.parseInt(quantity.getText().toString());
			
			switch (positionofitem) {
			case 0:
				itemprice=itemprice+(60*quant);

				break;
			case 1:
				itemprice=itemprice+(65*quant);

				break;
			case 2:
				itemprice=itemprice+(70*quant);

				break;
			case 3:
				itemprice=itemprice+(50*quant);

				break;
			case 4:
				itemprice=itemprice+(75*quant);

				break;
			case 5:
				itemprice=itemprice+(55*quant);

				break;
			case 6:
				itemprice=itemprice+(85*quant);

				break;
			case 7:
				itemprice=itemprice+(45*quant);

				break;
			case 8:
				itemprice=itemprice+(60*quant);

				break;

			
			}
			
			
		    if(Integer.parseInt(quantity.getText().toString())!=0)
		    {
		    	NoofItem=NoofItem+1;
		    	ordereditem.put((positionofitem+1),Integer.parseInt(quantity.getText().toString())
		    			);
		    }
			textitemtotalprice.setText(String.valueOf(itemprice));
			textitemtotal.setText(String.valueOf(NoofItem));
			
		}

	}

}
