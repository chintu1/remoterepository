package com.example.gharwalatifin;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;


import com.example.gharwalatifin.util.JSONParser;

import android.support.v7.app.ActionBarActivity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends ActionBarActivity implements OnClickListener {

	// Progress Dialog
		private ProgressDialog pDialog;
		EditText mobile,etPassword;
		Button check;
		String mobileNumber;
		

		// url to create new product
		private static String url = "http://myappchintu.16mb.com/gharwalatifin/UserAvablitiyCheck.php";
		private static String url_login = "http://myappchintu.16mb.com/gharwalatifin/logincheck.php";
		
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			mobile=(EditText)findViewById(R.id.editTextnumber);
			etPassword=(EditText)findViewById(R.id.editTextPassword);
			check=(Button)findViewById(R.id.buttonCheck);
			check.setOnClickListener(this);
		}

		@Override
		public boolean onCreateOptionsMenu(Menu menu) {
			// Inflate the menu; this adds items to the action bar if it is present.
			getMenuInflater().inflate(R.menu.main, menu);
			return true;
		}

		@Override
		public boolean onOptionsItemSelected(MenuItem item) {
			// Handle action bar item clicks here. The action bar will
			// automatically handle clicks on the Home/Up button, so long
			// as you specify a parent activity in AndroidManifest.xml.
			int id = item.getItemId();
			if (id == R.id.action_settings) {
				return true;
			}
			return super.onOptionsItemSelected(item);
		}

		/**
		 * Background Async Task to Create new product
		 * */
		class checkNumber extends AsyncTask<String, String, Boolean> {
			private static final String TAG_SUCCESS = "registered";
			JSONParser jsonParser = new JSONParser();
	        
			private static final String TAG = "checkNumber";

			/**
			 * Before starting background thread Show Progress Dialog
			 * */
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				pDialog = new ProgressDialog(MainActivity.this);
				pDialog.setMessage("Cheacking please wait..");
				pDialog.setIndeterminate(false);
				pDialog.setCancelable(true);
				pDialog.show();
			}

			/**
			 * Creating product
			 * */
			protected Boolean doInBackground(String... args) {

				String mobileNumber = mobile.getText().toString();
	           
				// Building Parameters
				List<NameValuePair> params = new ArrayList<NameValuePair>();

				params.add(new BasicNameValuePair("mobile", mobileNumber));

				// getting JSON Object
				// Note that create product url accepts POST method
				JSONObject json = jsonParser.makeHttpRequest(url,
						"POST", params);

				// check log cat fro response
				Log.d("Create Response", json.toString());

				// check for success tag
				try {
					int success = json.getInt(TAG_SUCCESS);

					if (success == 0) {

						Intent i = new Intent(MainActivity.this,SignupPage.class);
						startActivity(i);
						// closing this screen
						finish();

					} else {

	                    Log.i(TAG, "done");
					  return false;


					}
				} catch (JSONException e) {
					e.printStackTrace();
				}

				return false;
			}

			/**
			 * After completing background task Dismiss the progress dialog
			 * **/
			protected void onPostExecute(Boolean result) {
				// dismiss the dialog once done
				pDialog.dismiss();
				if(result==false)
				{
					mobile.setKeyListener(null);
					etPassword.setVisibility(View.VISIBLE);
					check.setText("Login");
				}
			}

		}

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			if(check.getText().toString().equals("Check"))
			{
			new checkNumber().execute();
			}
			
			if(check.getText().toString().equals("Login"))
			{
				new	Login().execute();
			}
		}
		
		/**
		 * Background Async Task to Create new product
		 * */
		class Login extends AsyncTask<String, String, Boolean> {
			private static final String TAG_Login = "login_response";
			JSONParser jsonParser = new JSONParser();
			

			private static final String TAG = "checkNumber";

			/**
			 * Before starting background thread Show Progress Dialog
			 * */
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				pDialog = new ProgressDialog(MainActivity.this);
				pDialog.setMessage("Login Process..");
				pDialog.setIndeterminate(false);
				pDialog.setCancelable(true);
				pDialog.show();
				
			}

			/**
			 * Creating product
			 * */
			protected Boolean doInBackground(String... args) {

				mobileNumber = mobile.getText().toString();
				String UserPassword=etPassword.getText().toString();
				// Building Parameters
				List<NameValuePair> params = new ArrayList<NameValuePair>();

				params.add(new BasicNameValuePair("mobile", mobileNumber));
				params.add(new BasicNameValuePair("userpassword", UserPassword));


				// getting JSON Object
				// Note that create product url accepts POST method
				JSONObject json1 = jsonParser.makeHttpRequest(url_login,
						"POST", params);

				// check log cat fro response
				Log.d("Create Response", json1.toString());

				// check for success tag
				try {
					int loginresponse = json1.getInt(TAG_Login);
					Log.i(TAG, "loginrespones="+loginresponse);

					if (loginresponse == 0) {

						Log.i(TAG, "worng password");
						// closing this screen
						return false;
						

					} else {

	                    Log.i(TAG, "login successfull");
					  return true;


					}
				} catch (JSONException e) {
					e.printStackTrace();
				}

				return false;
			}

			/**
			 * After completing background task Dismiss the progress dialog
			 * **/
			protected void onPostExecute(Boolean result) {
				// dismiss the dialog once done
				pDialog.dismiss();
				if(result)
				{
					Intent i = new Intent(MainActivity.this,Branch_activity_first.class);
					i.putExtra("mobile", mobileNumber);
					startActivity(i);
					// closing this screen
					finish();
					
				}
				else
				{
					AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
					builder.setMessage("Wrong Password!")
					       .setCancelable(false)
					       .setPositiveButton("OK", new DialogInterface.OnClickListener() {
					           public void onClick(DialogInterface dialog, int id) {
					        	   etPassword.setText("");
					        	   dialog.cancel();
					           }
					       });
					AlertDialog alert = builder.create();
					alert.show();

					
				}
				
			
				
			}

		}
		
		
}
