package com.example.gharwalatifin;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Thankyou extends Activity implements OnClickListener {

	// Animation
    Animation animFadein,animFadein1;
    Button homebt;
    ImageView image;
    TextView text;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_thankyou);
		image=(ImageView)findViewById(R.id.imageView1);
		homebt=(Button)findViewById(R.id.button1);
		homebt.setOnClickListener(this);
		// load the animation
        animFadein = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.zoom_out);  
        image.startAnimation(animFadein);
        text=(TextView)findViewById(R.id.textView1);
        animFadein1 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.blink); 
        text.startAnimation(animFadein1);
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.thankyou, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		Intent i = new Intent(this,MainActivity.class);
		startActivity(i);
		finish();
		
	}
}
