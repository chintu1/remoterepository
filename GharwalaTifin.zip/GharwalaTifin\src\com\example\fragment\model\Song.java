package com.example.fragment.model;

public class Song {
	String songName;
	String songPath;
	int icon;
	public Song(String songName, int icon) {
		super();
		this.songName = songName;
		this.icon=icon;
	}
	public String getSongName() {
		return songName;
	}
	public void setSongName(String songName) {
		this.songName = songName;
	}

	public int getIcon() {
		return icon;
	}
	public void setIcon(int icon) {
		this.icon = icon;
	}



}
