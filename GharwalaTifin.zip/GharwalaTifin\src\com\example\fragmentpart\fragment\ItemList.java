package com.example.fragmentpart.fragment;

import java.util.ArrayList;
import java.util.Map;

import com.example.fragment.model.Song;
import com.example.gharwalatifin.CustomAdapter;
import com.example.gharwalatifin.R;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import com.example.fragmentpart.*;


public class ItemList extends Fragment implements OnItemClickListener {
	
	
	String [] itemlist={"veg thali with rice","Non. veg thal without rice",
			"Veg. thali with roti","Combo thali","Non.veg thali with roti"};
	ListView listitem;
	SimpleAdapter item;
	Context context;
	OnitemSelectedListener mCallBack;
	Song song;
	ArrayList< Song> songsList2 = new ArrayList<Song>();
	String [] itemname={"veg thali with rice","Non. veg thal without rice",
			"Veg. thali with roti","Combo thali","Non.veg thali with roti"
			,"Dosa","South indian special","South indian Non.veg"};
	int[] itemimage={R.drawable.item0,R.drawable.item1,R.drawable.item2,
			R.drawable.item3,R.drawable.item4,R.drawable.item5,
			R.drawable.item6,R.drawable.item7,R.drawable.item8};
	
	CustomAdapter adapter;
	
	public interface OnitemSelectedListener {
		public void onitemSelected(String title , int position);
	}
	
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		//Log.i(TAG, "onAttach()");

		super.onAttach(activity);
		 context= activity.getBaseContext();
		 try {
				mCallBack = (OnitemSelectedListener)activity;
				
			} catch (ClassCastException e) {
				throw new ClassCastException(activity.toString()
						+ " must implement OnHeadlineSelectedListener");
			}
	}

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view=inflater.inflate(R.layout.activity_itemlist, null);
		listitem=(ListView)view.findViewById(R.id.listViewItem);
		
		
		
		for(int i=0;i<=7;i++)
		{
			
	     	Song song = new Song(itemname[i], itemimage[i]);
			songsList2.add(song);

			
		}
		
		adapter = new CustomAdapter(this,songsList2);
		// SimpleAdapter adapter1 = new SimpleAdapter(null, null, progress, Songs, icon);
		listitem.setAdapter(adapter);
		/*ArrayAdapter<String> adapter = new ArrayAdapter<String>(context,
                android.R.layout.simple_list_item_1, itemlist);
    
        listitem.setAdapter(adapter);*/
        listitem.setOnItemClickListener(this);
		super.onCreateView(inflater, container, savedInstanceState);
		return view;
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		int position=arg2;
		song  = (Song)adapter.getItemAtPosition(position);
		String itemname=song.getSongName().toString();

		mCallBack.onitemSelected(itemname, position);
		
	}

	

}
